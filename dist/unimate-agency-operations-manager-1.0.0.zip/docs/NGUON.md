# Nguồn của agent `agency-operations-manager`

Một agent lẻ của gói `unimate.agency-agents`, lấy từ [msitarzewski/agency-agents/specialized/operations-manager.md](https://github.com/msitarzewski/agency-agents/blob/main/specialized/operations-manager.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho UNI MATE (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, UNI MATE báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
