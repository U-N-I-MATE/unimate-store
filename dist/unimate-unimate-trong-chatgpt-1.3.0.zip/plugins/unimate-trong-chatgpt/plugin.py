"""UNI MATE trong ChatGPT: cho ChatGPT gọi công cụ của UNI MATE qua một MCP connector.

Vì sao là một gói, không phải tính năng có sẵn
----------------------------------------------
Bản 0.64.21 đưa cửa này vào lõi UNI MATE. Chủ repo gỡ nó ở 0.64.26 vì nó đi ngược nguyên tắc của
UNI MATE: mọi cuộc chat nằm chung MỘT nền tảng. Ai vẫn muốn chat trên chatgpt.com bằng gói của
mình thì cài gói này, và việc cài là lựa chọn có chủ ý của họ.

Cách chạy
---------
Người dùng chat trên chatgpt.com như bình thường, còn ChatGPT (Developer mode) tự gọi sang
UNI MATE qua tính năng MCP connector chính thức. UNI MATE vốn đã là một MCP server đầy đủ (hub mà
Claude Code và Codex dùng); gói này chỉ thêm CỬA: OAuth 2.1 tối giản, đúng phần ChatGPT dùng.

  - khám phá: RFC 9728 (protected resource) + RFC 8414 (authorization server)
  - đăng ký client động: RFC 7591 (ChatGPT tự đăng ký, không phải dán client id)
  - mã cấp quyền + PKCE S256 (bắt buộc, không nhận `plain`)
  - làm mới token có XOAY vòng (dùng lại refresh cũ là thu hồi cả họ), thu hồi: RFC 7009

Bước "Cho phép" dựa vào ĐĂNG NHẬP DASHBOARD sẵn có (mật khẩu + 2FA), không thêm bí mật nào.

Cần UNI MATE 0.64.26 trở lên: bản đó mở `ctx.register_http` và `ctx.register_well_known`.

Ranh giới an toàn
-----------------
- UNI MATE chưa có mật khẩu quản trị thì mọi cửa OAuth trả 404: cửa đồng ý dựa vào đăng nhập.
- `redirect_uri` chỉ nhận máy của OpenAI, và từ 1.1.0 ĐÚNG một địa chỉ quay về của Claude.ai do
  Anthropic công bố. Kẻ tự đăng ký client trỏ về máy mình rồi dụ chủ bấm "Cho phép" sẽ không nhận
  được mã.
- Token, mã cấp quyền chỉ lưu dạng BĂM SHA-256. Tệp lộ ra không dùng được để gọi.
- Token của cửa này KHÔNG phải `hub_token` của Claude Code/Codex, và ngược lại.
- Mức quyền (full / auto / suggest) chủ chọn trên trang của gói; hub ép ở lớp cứng như mọi
  engine khác, đọc lại TỪNG lượt gọi nên hạ quyền có hiệu lực ngay. Từ 1.1.0 cài mới mặc định
  Ghi nháp (auto); bản đã cài giữ mức đang chạy.
- 1.1.0 thêm ba tool chỉ cửa này có: liệt kê, đọc hội thoại của chủ và ghi lại điều đã chốt thành
  hội thoại "Từ ChatGPT: ..." (mục "Hội thoại của chủ" bên dưới; cần UNI MATE 0.441.0).
- 1.2.0 thêm hai tool GỬI tin vào một hội thoại ở khung Trò chuyện chính như chủ gõ, và đọc câu trả
  lời. CHỈ ở mức Toàn quyền: một lượt chat của chủ chạy với quyền của chủ, nên mức thấp hơn mà gửi
  được là đi vòng qua chính mức đó. Cần UNI MATE 0.446.0; lõi cũ hơn thì hai tool này không hiện.
- 1.3.0 GHIM bộ não cho cổng (chủ chốt 04/11/2026). "Brain đang mở" của lõi là brain của hội thoại cập nhật
  gần nhất trên cả máy, kể cả hội thoại chạy nền, nên cổng từng nhảy bộ não sau một lần khởi động lại. Chủ chọn
  bộ não ở đầu trang gói; CHƯA chọn thì mọi tool hội thoại của cổng báo lỗi kèm địa chỉ trang gói, không tự
  dùng Brain mặc định hay brain đang mở. Bộ não đã ghim mất thì báo lỗi, không rơi sang bộ não khác. Mọi kết
  quả ghi tên bộ não. Gửi tin không kèm chat_id thì tạo hội thoại mới ở bộ não đó. Cần UNI MATE 0.447.0;
  lõi cũ hơn thì cổng theo hội thoại gần nhất như 1.2.0.
- Các cửa máy chủ OpenAI gọi (đổi token, MCP...) khai `no_cookie`: lõi UNI MATE gỡ cookie trước
  khi giao request cho gói, nên không trang lạ nào mượn được phiên của chủ qua đó.
"""
from __future__ import annotations

import base64
import hashlib
import html
import json
import os
import secrets
import threading
import time
from pathlib import Path
from urllib.parse import urlencode, urlparse

TTL_ACCESS = 3600                   # 1 giờ; ChatGPT tự làm mới
TTL_REFRESH = 30 * 24 * 3600        # 30 ngày không dùng thì phải cho phép lại
TTL_MA = 300                        # mã cấp quyền sống 5 phút, dùng MỘT lần
TTL_YEU_CAU = 600                   # trang Cho phép mở quá 10 phút thì bắt đầu lại từ ChatGPT
MAX_CLIENT = 20                     # chặn ai đó đăng ký client tới đầy đĩa
MAX_YEU_CAU = 100
MUC_QUYEN = ("full", "auto", "suggest")
# 1.1.0 (quyết định của chủ 04/11/2026): cài mới mặc định Ghi nháp. Muốn Toàn quyền thì tự bật trên
# trang của gói. Bản đã cài từ trước giữ nguyên mức đang chạy (xem `_giu_muc_ban_cu`).
MUC_MAC_DINH = "auto"
MUC_BAN_CU = "full"                 # mặc định của 1.0.0
GAN_NHAT = "__gan_nhat__"          # lựa chọn phụ "Theo hội thoại gần nhất" (1.3.0)

_HOST_REDIRECT = ("chatgpt.com", "chat.openai.com")
_DUOI_REDIRECT = (".chatgpt.com", ".openai.com")
# 1.1.0 (chủ duyệt 04/11/2026): Claude.ai (web, Desktop, điện thoại) nối được, chỉ qua ĐÚNG một địa chỉ
# quay về mà Anthropic công bố, so nguyên văn cả chuỗi, không nhận đuôi tên miền. Nguồn: tài liệu
# "Authentication for connectors", mục Callback URLs (claude.com/docs/connectors/building/authentication),
# đối chiếu 04/11/2026: "register exactly this redirect URI: https://claude.ai/api/mcp/auth_callback".
# Địa chỉ claude.com chưa có trong tài liệu của Anthropic nên KHÔNG nhận. Claude Code (quay về localhost)
# không thuộc phạm vi gói: Claude Code đã nối thẳng hub của UNI MATE.
_REDIRECT_CLAUDE = ("https://claude.ai/api/mcp/auth_callback",)

_KHOA = threading.Lock()

HUONG_DAN = ("https://github.com/U-N-I-MATE/unimate-store/blob/main/packs/"
             "unimate.unimate-trong-chatgpt/docs/HUONG-DAN.md")


# ============================================================
# Đường và địa chỉ
# ============================================================

def _p(ctx, duoi: str = "") -> str:
    """Đường tuyệt đối của gói trên UNI MATE: /ext/<slug>/<duoi>."""
    return f"/ext/{ctx.slug}/" + duoi


def _goc(request) -> str:
    """Gốc công khai của UNI MATE, không có "/" cuối.

    Ưu tiên tên miền riêng đã khai ở trang Thương hiệu: nó ỔN ĐỊNH, còn header proxy thì đổi
    theo đường người ta đi vào. Issuer của OAuth mà đổi giữa chừng là ChatGPT coi như máy khác."""
    try:
        import config as cfgmod
        custom = ((cfgmod.read_settings().get("domain") or {}).get("custom") or "").strip().lower()
    except Exception:
        custom = ""
    if custom:
        return f"https://{custom}"
    import web_security
    return web_security.external_base(
        request.url.scheme, request.url.netloc, request.headers.get("x-forwarded-proto", ""),
        request.headers.get("x-forwarded-host", "")).rstrip("/")


def _co_mat_khau() -> bool:
    try:
        import config as cfgmod
        return bool(cfgmod.auth_enabled())
    except Exception:
        return False


def _co_phien(request) -> bool:
    import config as cfgmod
    return bool(cfgmod.valid_session(request.cookies.get("unimate_session", "")))


def metadata_as(ctx, goc: str) -> dict:
    return {
        "issuer": goc,
        "authorization_endpoint": goc + _p(ctx, "oauth/authorize"),
        "token_endpoint": goc + _p(ctx, "oauth/token"),
        "registration_endpoint": goc + _p(ctx, "oauth/register"),
        "revocation_endpoint": goc + _p(ctx, "oauth/revoke"),
        "response_types_supported": ["code"],
        "response_modes_supported": ["query"],
        "grant_types_supported": ["authorization_code", "refresh_token"],
        "code_challenge_methods_supported": ["S256"],
        "token_endpoint_auth_methods_supported": ["none"],
        "scopes_supported": ["unimate"],
    }


def metadata_pr(ctx, goc: str) -> dict:
    return {
        "resource": goc + _p(ctx, "mcp"),
        "authorization_servers": [goc],
        "scopes_supported": ["unimate"],
        "bearer_methods_supported": ["header"],
        "resource_name": "UNI MATE",
    }


def www_authenticate(ctx, goc: str, mo_ta: str = "") -> str:
    """Câu thách thức trả kèm 401. ChatGPT đọc `resource_metadata` để biết đi đâu đăng nhập.
    `mo_ta` PHẢI là ASCII: header HTTP chỉ nhận Latin-1, viết tiếng Việt vào là trả 500."""
    mo_ta = mo_ta.encode("ascii", "ignore").decode()
    phan = ['Bearer realm="unimate"', 'error="invalid_token"']
    if mo_ta:
        phan.append(f'error_description="{mo_ta}"')
    phan.append(f'resource_metadata="{goc}/.well-known/oauth-protected-resource{_p(ctx, "mcp")}"')
    return ", ".join(phan)


# ============================================================
# Cài đặt + kho (thư mục dữ liệu riêng của gói, không nằm trong brain)
# ============================================================

def _doc_json(p, mac_dinh: dict) -> dict:
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return mac_dinh


def _ghi_json(p, d: dict) -> None:
    tam = p.with_suffix(".tmp")
    tam.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")
    try:
        os.chmod(tam, 0o600)
    except OSError:
        pass
    os.replace(tam, p)


def muc_quyen(ctx) -> str:
    m = _doc_json(ctx.data_dir / "cai-dat.json", {}).get("muc_quyen")
    return m if m in MUC_QUYEN else MUC_MAC_DINH


def dat_muc_quyen(ctx, m: str) -> bool:
    if m not in MUC_QUYEN:
        return False
    with _KHOA:
        d = _doc_json(ctx.data_dir / "cai-dat.json", {})
        d["muc_quyen"] = m
        _ghi_json(ctx.data_dir / "cai-dat.json", d)
    return True


def bo_nao_ghim(ctx) -> str:
    """Bộ não chủ ghim cho cổng (1.3.0): đường dẫn, GAN_NHAT, hoặc rỗng khi chưa chọn."""
    return str(_doc_json(ctx.data_dir / "cai-dat.json", {}).get("bo_nao") or "")


def dat_bo_nao(ctx, v: str) -> bool:
    """Ghim bộ não. Chỉ nhận GAN_NHAT hoặc đúng đường dẫn một bộ não lõi đang liệt kê."""
    v = str(v or "")
    G = _gate()
    if v != GAN_NHAT and not (co_ghim(G) and any(b["path"] == v for b in G.list_brains())):
        return False
    with _KHOA:
        d = _doc_json(ctx.data_dir / "cai-dat.json", {})
        d["bo_nao"] = v
        _ghi_json(ctx.data_dir / "cai-dat.json", d)
    return True


def _giu_muc_ban_cu(ctx) -> None:
    """Chạy MỘT lần, lúc bản 1.1.0 trở lên nạp lần đầu.

    Bản 1.0.0 không ghi mức nào khi chủ chưa từng chọn, nó chạy theo mặc định cũ (Toàn quyền). Có
    `kho.json` nghĩa là gói đã từng kết nối, tức là ChatGPT đang làm việc ở Toàn quyền: ghi hẳn mức đó
    ra để bản mới không tự hạ quyền giữa chừng. Cài mà chưa kết nối lần nào thì chưa có gì để giữ, nhận
    mặc định mới. Dấu `muc_da_chot` chặn chạy lại: kết nối lần đầu SAU khi lên 1.1.0 không bị tính là
    bản cũ."""
    p = ctx.data_dir / "cai-dat.json"
    with _KHOA:
        d = _doc_json(p, {})
        if d.get("muc_da_chot"):
            return
        if d.get("muc_quyen") not in MUC_QUYEN and (ctx.data_dir / "kho.json").is_file():
            d["muc_quyen"] = MUC_BAN_CU
        d["muc_da_chot"] = True
        _ghi_json(p, d)


def _doc(ctx) -> dict:
    """Kho: client, token, yêu cầu đang chờ Cho phép, mã cấp quyền. Nằm TRÊN ĐĨA chứ không
    trong RAM: UNI MATE nạp lại plugin mỗi khi bật/tắt một plugin bất kỳ, và một yêu cầu đang chờ
    mà mất giữa chừng là người dùng bấm Cho phép rồi nhận câu "quá hạn"."""
    d = _doc_json(ctx.data_dir / "kho.json", {})
    for k in ("clients", "tokens", "yeu_cau", "ma"):
        if not isinstance(d.get(k), dict):
            d[k] = {}
    return d


def _ghi(ctx, d: dict) -> None:
    # Chỉ dọn bản HẾT HẠN. Token đã thu hồi giữ tới hạn của nó: refresh đã xoay mà bị dùng lại
    # là dấu hiệu có người cầm bản sao, và phải còn bản ghi thì mới nhận ra được.
    now = time.time()
    for k in ("tokens", "yeu_cau", "ma"):
        d[k] = {h: t for h, t in d[k].items() if t.get("het", 0) > now}
    _ghi_json(ctx.data_dir / "kho.json", d)


def _bam(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def _s256(verifier: str) -> str:
    return base64.urlsafe_b64encode(
        hashlib.sha256(verifier.encode("ascii")).digest()).decode().rstrip("=")


def la_claude(uri: str) -> bool:
    return uri in _REDIRECT_CLAUDE


def redirect_hop_le(uri: str) -> bool:
    if la_claude(uri):
        return True
    try:
        u = urlparse(uri)
    except Exception:
        return False
    if u.scheme != "https" or not u.hostname:
        return False
    h = u.hostname.lower()
    return h in _HOST_REDIRECT or any(h.endswith(d) for d in _DUOI_REDIRECT)


def _noi(uri: str, q: dict) -> str:
    return uri + ("&" if "?" in uri else "?") + urlencode(q)


# ============================================================
# Luồng OAuth
# ============================================================

def dang_ky_client(ctx, body: dict) -> tuple:
    """(mã HTTP, JSON). RFC 7591, chỉ phần ChatGPT dùng: client công khai, không bí mật."""
    uris = body.get("redirect_uris") if isinstance(body, dict) else None
    if not isinstance(uris, list) or not uris or not all(
            isinstance(u, str) and redirect_hop_le(u) for u in uris):
        return 400, {"error": "invalid_redirect_uri",
                     "error_description": "redirect_uris phải là địa chỉ https của ChatGPT hoặc Claude"}
    ten = str(body.get("client_name") or ("Claude" if any(map(la_claude, uris)) else "ChatGPT"))[:120]
    with _KHOA:
        d = _doc(ctx)
        if len(d["clients"]) >= MAX_CLIENT:
            # Bỏ client cũ nhất CHƯA từng nhận token: đó là những lần kết nối bỏ dở.
            dang_dung = {t.get("client") for t in d["tokens"].values()}
            cu = sorted((c for c in d["clients"].values() if c["id"] not in dang_dung),
                        key=lambda c: c.get("tao", 0))
            if not cu:
                return 400, {"error": "invalid_client_metadata",
                             "error_description": "Quá nhiều kết nối. Ngắt bớt trên trang của gói."}
            d["clients"].pop(cu[0]["id"], None)
        cid = "chatgpt-" + secrets.token_urlsafe(16)
        d["clients"][cid] = {"id": cid, "ten": ten, "redirect_uris": uris, "tao": time.time()}
        _ghi(ctx, d)
    return 201, {"client_id": cid, "client_name": ten, "redirect_uris": uris,
                 "token_endpoint_auth_method": "none",
                 "grant_types": ["authorization_code", "refresh_token"],
                 "response_types": ["code"]}


def bat_dau_uy_quyen(ctx, q: dict) -> tuple:
    """Kiểm yêu cầu từ ChatGPT.

    ("trang_loi", câu)   - không tin được redirect_uri nên KHÔNG được chuyển hướng về đó
    ("chuyen", url)      - lỗi báo ngược về ChatGPT theo đúng OAuth
    ("ok", yeu_cau)      - hiện trang Cho phép
    """
    cid = str(q.get("client_id") or "")
    with _KHOA:
        d = _doc(ctx)
        client = d["clients"].get(cid)
        if not client:
            return "trang_loi", "Không nhận ra kết nối này. Mở lại ChatGPT hoặc Claude và bấm kết nối lại."
        ru = str(q.get("redirect_uri") or "")
        if ru not in client["redirect_uris"]:
            return "trang_loi", "Địa chỉ quay về không khớp với lúc đăng ký."
        state = str(q.get("state") or "")
        if q.get("response_type") != "code":
            return "chuyen", _noi(ru, {"error": "unsupported_response_type",
                                       "error_description": "chỉ hỗ trợ code", "state": state})
        if not q.get("code_challenge") or q.get("code_challenge_method") != "S256":
            return "chuyen", _noi(ru, {"error": "invalid_request",
                                       "error_description": "bắt buộc PKCE S256", "state": state})
        yc = {"id": secrets.token_urlsafe(24), "client": cid, "ten": client["ten"],
              "redirect_uri": ru, "state": state, "challenge": str(q["code_challenge"])[:128],
              "het": time.time() + TTL_YEU_CAU}
        while len(d["yeu_cau"]) >= MAX_YEU_CAU:
            d["yeu_cau"].pop(min(d["yeu_cau"], key=lambda k: d["yeu_cau"][k]["het"]), None)
        d["yeu_cau"][yc["id"]] = yc
        _ghi(ctx, d)
    return "ok", yc


def ket_thuc_uy_quyen(ctx, yid: str, cho_phep: bool):
    """Chủ bấm Cho phép / Từ chối. Trả URL quay về ChatGPT, hoặc None nếu yêu cầu hết hạn."""
    with _KHOA:
        d = _doc(ctx)
        yc = d["yeu_cau"].pop(yid or "", None)
        if not yc or yc.get("het", 0) < time.time():
            _ghi(ctx, d)
            return None
        q = {}
        if cho_phep:
            ma = secrets.token_urlsafe(32)
            d["ma"][_bam(ma)] = {"client": yc["client"], "redirect_uri": yc["redirect_uri"],
                                 "challenge": yc["challenge"], "het": time.time() + TTL_MA}
            q["code"] = ma
        else:
            q = {"error": "access_denied", "error_description": "chủ UNI MATE từ chối"}
        if yc["state"]:
            q["state"] = yc["state"]
        _ghi(ctx, d)
    return _noi(yc["redirect_uri"], q)


def _cap_token(d: dict, cid: str, ho: str) -> dict:
    """Một cặp access + refresh. `ho` gom các thế hệ refresh của cùng một lần cho phép."""
    now = time.time()
    at, rt = secrets.token_urlsafe(32), secrets.token_urlsafe(40)
    d["tokens"][_bam(at)] = {"loai": "access", "client": cid, "ho": ho, "het": now + TTL_ACCESS}
    d["tokens"][_bam(rt)] = {"loai": "refresh", "client": cid, "ho": ho, "het": now + TTL_REFRESH}
    return {"access_token": at, "token_type": "Bearer", "expires_in": TTL_ACCESS,
            "refresh_token": rt, "scope": "unimate"}


def doi_token(ctx, f: dict) -> tuple:
    """(mã HTTP, JSON) cho POST token. Client công khai: không có client_secret, chỉ PKCE."""
    loai = f.get("grant_type")
    cid = str(f.get("client_id") or "")
    if loai == "authorization_code":
        ma, ver = str(f.get("code") or ""), str(f.get("code_verifier") or "")
        if not ma or not ver or not cid:
            return 400, {"error": "invalid_request"}
        with _KHOA:
            d = _doc(ctx)
            rec = d["ma"].pop(_bam(ma), None)       # MỘT lần, kể cả khi các bước sau hỏng
            _ghi(ctx, d)
            if not rec or rec["client"] != cid or rec.get("het", 0) < time.time():
                return 400, {"error": "invalid_grant"}
            ru = f.get("redirect_uri")
            if ru and ru != rec["redirect_uri"]:
                return 400, {"error": "invalid_grant", "error_description": "redirect_uri không khớp"}
            if not secrets.compare_digest(_s256(ver), rec["challenge"]):
                return 400, {"error": "invalid_grant", "error_description": "PKCE không khớp"}
            if cid not in d["clients"]:
                return 400, {"error": "invalid_client"}
            out = _cap_token(d, cid, secrets.token_urlsafe(12))
            _ghi(ctx, d)
        return 200, out
    if loai == "refresh_token":
        rt = str(f.get("refresh_token") or "")
        if not rt or not cid:
            return 400, {"error": "invalid_request"}
        with _KHOA:
            d = _doc(ctx)
            rec = d["tokens"].get(_bam(rt))
            if not rec or rec.get("loai") != "refresh" or rec.get("client") != cid:
                return 400, {"error": "invalid_grant"}
            if rec.get("thu_hoi"):
                # Refresh ĐÃ XOAY mà còn bị dùng lại: có người cầm bản sao. Thu hồi cả họ, bắt
                # cho phép lại, thay vì để hai bên cùng giữ một kết nối.
                for t in d["tokens"].values():
                    if t.get("ho") == rec.get("ho"):
                        t["thu_hoi"] = True
                _ghi(ctx, d)
                return 400, {"error": "invalid_grant", "error_description": "refresh đã dùng rồi"}
            if rec["het"] < time.time():
                return 400, {"error": "invalid_grant"}
            rec["thu_hoi"] = True
            out = _cap_token(d, cid, rec["ho"])
            _ghi(ctx, d)
        return 200, out
    return 400, {"error": "unsupported_grant_type"}


def kiem_token(ctx, raw: str):
    """Bản ghi của một access token còn hạn, hoặc None."""
    if not raw:
        return None
    rec = _doc(ctx)["tokens"].get(_bam(raw))
    if not rec or rec.get("loai") != "access" or rec.get("thu_hoi") or rec["het"] < time.time():
        return None
    return rec


def thu_hoi(ctx, raw: str) -> None:
    """RFC 7009: thu hồi một token và cả họ của nó. Không nói token có tồn tại hay không."""
    if not raw:
        return
    with _KHOA:
        d = _doc(ctx)
        rec = d["tokens"].get(_bam(raw))
        if not rec:
            return
        for t in d["tokens"].values():
            if t.get("ho") == rec.get("ho"):
                t["thu_hoi"] = True
        _ghi(ctx, d)


def ngat_tat_ca(ctx) -> int:
    """Nút "Ngắt mọi kết nối": xoá sạch client, token, yêu cầu, mã. Trả số client đã xoá."""
    with _KHOA:
        n = len(_doc(ctx)["clients"])
        _ghi(ctx, {"clients": {}, "tokens": {}, "yeu_cau": {}, "ma": {}})
    return n


def so_ket_noi(ctx) -> int:
    """Số lần cho phép còn hiệu lực (mỗi họ refresh còn sống là một)."""
    now = time.time()
    return len({t.get("ho") for t in _doc(ctx)["tokens"].values()
                if t.get("loai") == "refresh" and not t.get("thu_hoi") and t.get("het", 0) > now})


# ============================================================
# Hội thoại của chủ (1.1.0, cần UNI MATE 0.441.0: server/gate_api.py)
# ============================================================
# Ba tool này CHỈ AI nối qua cửa này thấy: gói chèn chúng vào câu trả lời tools/list của chính cửa
# mình và tự xử lý tools/call của chúng, không đăng ký qua `ctx.register_tool` (tool plugin hiện ra
# cho MỌI engine của UNI MATE, kể cả Claude Code của chủ, và ở đó chúng vô nghĩa).
#
# Mức quyền: Chỉ đọc thấy hai tool đọc; Ghi nháp và Toàn quyền thấy thêm tool ghi; CHỈ Toàn quyền
# thấy hai tool gửi tin và đọc kết quả (1.2.0, cần UNI MATE 0.446.0). Ngoài danh sách, lúc gọi còn
# kiểm lại mức (đọc từng lượt), nên AI gọi thẳng tên tool cũng không lách được.
# Hội thoại nào được đọc, được gửi là việc của `gate_api` ở lõi: đọc chỉ hội thoại của chủ, gửi chỉ
# vào khung Trò chuyện chính (chủ chốt 04/11/2026), không bao giờ hội thoại khách, nhóm Zalo hay Team.

T_DANH_SACH = "unimate_gate_list_chats"
T_DOC = "unimate_gate_read_chat"
T_GHI = "unimate_gate_record_note"
T_GUI = "unimate_gate_send_chat"
T_KET_QUA = "unimate_gate_chat_result"
_BAC = {"suggest": 0, "auto": 1, "full": 2}
_MUC_TOI_THIEU = {T_DANH_SACH: "suggest", T_DOC: "suggest", T_GHI: "auto", T_GUI: "full", T_KET_QUA: "full"}
_TOOL_GUI = (T_GUI, T_KET_QUA)   # cần `gate_api.send_chat` (UNI MATE 0.446.0)

_TOOL_CONG = {
    T_DANH_SACH: {
        "description": (
            "Liệt kê các hội thoại gần nhất của chủ với UNI MATE trong brain đang mở, mới nhất trước: "
            "chat trên dashboard, Telegram, Zalo cá nhân và với trợ lý (agent). Không có hội thoại khách "
            "hàng, nhóm Zalo hay Team. Trả id, tiêu đề, kênh, lúc cập nhật, số tin. Dùng id với "
            f"{T_DOC} để đọc."),
        "inputSchema": {"type": "object", "properties": {
            "query": {"type": "string", "description": "Lọc theo chữ trong tiêu đề hoặc đoạn đầu (tuỳ chọn)."},
            "limit": {"type": "integer", "minimum": 1, "maximum": 50,
                      "description": "Số hội thoại, mặc định 20, tối đa 50."}}},
    },
    T_DOC: {
        "description": (
            "Đọc các tin gần nhất của MỘT hội thoại của chủ (id lấy từ "
            f"{T_DANH_SACH}), cũ trước mới sau. has_more = true nghĩa là còn tin cũ hơn chưa trả."),
        "inputSchema": {"type": "object", "required": ["chat_id"], "properties": {
            "chat_id": {"type": "string", "description": "id hội thoại."},
            "limit": {"type": "integer", "minimum": 1, "maximum": 100,
                      "description": "Số tin, mặc định 30, tối đa 100."}}},
    },
    T_GHI: {
        "description": (
            "Ghi lại điều chủ vừa CHỐT ở đây thành một hội thoại mới trong UNI MATE, tiêu đề "
            "\"Từ ChatGPT: ...\" (hoặc \"Từ Claude: ...\"), để UNI MATE nhớ và tự học như một lượt chat "
            "bình thường. Không chạy model, không tốn lượt. Chỉ dùng khi chủ bảo ghi lại, lưu lại hay "
            "báo cho UNI MATE. Viết note là kết quả đã chốt (số liệu, quyết định, việc cần làm), không chép "
            "cả cuộc trò chuyện."),
        "inputSchema": {"type": "object", "required": ["title", "note"], "properties": {
            "title": {"type": "string", "description": "Tiêu đề ngắn, tối đa 120 ký tự."},
            "note": {"type": "string", "description": "Nội dung đã chốt, tối đa 20.000 ký tự."},
            "asked": {"type": "string", "description": "Câu chủ hỏi ban đầu (tuỳ chọn)."}}},
    },
    T_GUI: {
        "description": (
            "Gửi MỘT tin vào một hội thoại ở khung Trò chuyện chính của UNI MATE (id lấy từ "
            f"{T_DANH_SACH}, kênh web), như chủ tự gõ: UNI MATE chạy một lượt chat thật trong hội thoại "
            "đó, dùng bộ não, công cụ và quyền của chủ. Không truyền chat_id thì tạo hội thoại MỚI ở khung "
            "Trò chuyện chính, tiêu đề \"Từ ChatGPT: <title>\" hoặc \"Từ Claude: <title>\". Chỉ dùng khi chủ "
            "bảo gửi, giao hay nhờ UNI MATE làm việc. Hội thoại đang trả lời dở thì tin thành tin gõ thêm. "
            "Không gửi được vào hội thoại với Cộng sự, Telegram, Zalo, khách hàng, nhóm hay Team. Xong gọi "
            f"{T_KET_QUA} với chat_id và after_id trả về để lấy câu trả lời."),
        "inputSchema": {"type": "object", "required": ["message"], "properties": {
            "chat_id": {"type": "string",
                        "description": "id hội thoại ở khung Trò chuyện chính; bỏ trống để tạo hội thoại mới."},
            "title": {"type": "string",
                      "description": "Tiêu đề ngắn cho hội thoại mới (chỉ dùng khi không có chat_id; tuỳ chọn)."},
            "message": {"type": "string", "description": "Nội dung gửi, tối đa 7.000 ký tự."}}},
    },
    T_KET_QUA: {
        "description": (
            f"Chờ UNI MATE trả lời tin vừa gửi bằng {T_GUI} (tối đa wait giây, mặc định 25, tối đa 50) rồi "
            "trả câu trả lời. status = done: có câu trả lời; running: UNI MATE vẫn đang làm, gọi lại với "
            "cùng after_id; no_answer: lượt đã dừng hoặc lỗi, đọc lại hội thoại để xem."),
        "inputSchema": {"type": "object", "required": ["chat_id", "after_id"], "properties": {
            "chat_id": {"type": "string", "description": "id hội thoại đã gửi."},
            "after_id": {"type": "integer", "description": f"after_id do {T_GUI} trả về."},
            "wait": {"type": "integer", "minimum": 0, "maximum": 50,
                     "description": "Số giây chờ tối đa, mặc định 25."}}},
    },
}


def _gate():
    """Module `gate_api` của lõi, hoặc None khi UNI MATE cũ hơn 0.441.0 (gói vẫn chạy, chỉ thiếu ba tool)."""
    try:
        import gate_api
        return gate_api
    except Exception:
        return None


def du_muc(muc: str, ten: str) -> bool:
    return _BAC.get(muc, -1) >= _BAC[_MUC_TOI_THIEU[ten]]


def co_ghim(G) -> bool:
    """Lõi có danh sách bộ não để ghim (UNI MATE 0.447.0) không."""
    return G is not None and hasattr(G, "list_brains")


def co_gui(G) -> bool:
    """Lõi có phần gửi tin vào hội thoại (UNI MATE 0.446.0) không."""
    return G is not None and hasattr(G, "send_chat") and hasattr(G, "chat_result")


def tool_cong(muc: str) -> list:
    """Định nghĩa tool (dạng MCP) mà AI nối qua cửa này được thấy ở mức `muc`."""
    G = _gate()
    if G is None:
        return []
    return [{"name": ten, **dn} for ten, dn in _TOOL_CONG.items()
            if du_muc(muc, ten) and (ten not in _TOOL_GUI or co_gui(G))]


def nguon_cua_client(ctx, rec: dict) -> str:
    """"ChatGPT" hay "Claude". Dựa vào địa chỉ quay về đã đăng ký (tên client là chữ tự khai, ai cũng
    đặt được), chỉ khi không có mới xem tên."""
    c = _doc(ctx)["clients"].get((rec or {}).get("client") or "") or {}
    uris = c.get("redirect_uris") or []
    if uris:
        return "Claude" if any(la_claude(u) for u in uris) else "ChatGPT"
    return "Claude" if "claude" in str(c.get("ten") or "").casefold() else "ChatGPT"


def _brain_dang_mo() -> str:
    import mcp_hub
    v = mcp_hub.resolve_vault(None)[0]
    return str(v) if v else ""


def _ten_bo_nao(path: str) -> str:
    try:
        import brain_label
        return brain_label.display(Path(path))
    except Exception:
        return Path(path).name


def trang_goi(ctx, goc: str) -> str:
    """Địa chỉ trang gói, để lời báo lỗi chỉ đúng chỗ chủ cần mở."""
    return (goc or "") + _p(ctx)


def bo_nao_cong(ctx, goc: str = "") -> tuple:
    """(đường dẫn, tên hiển thị, lỗi) của bộ não cổng làm việc ở lượt này (1.3.0).

    Đã ghim một bộ não thì LUÔN là bộ não đó, không đổi theo hoạt động trên dashboard. Chưa chọn thì báo lỗi
    kèm địa chỉ trang gói, không tự dùng Brain mặc định hay brain đang mở: sau một lần khởi động lại, hội thoại
    mới nhất có thể là UNI MATE Core của Brain Default, nên tự đoán là ghim nhầm. Lõi cũ hơn 0.447.0 (chưa có
    danh sách bộ não) thì theo hội thoại gần nhất như 1.2.0."""
    G = _gate()
    v = bo_nao_ghim(ctx)
    if not co_ghim(G) or v == GAN_NHAT:
        p = _brain_dang_mo()
        if not p:
            return "", "", "UNI MATE chưa có brain đang mở. Mở một brain trên dashboard rồi thử lại."
        return p, _ten_bo_nao(p), ""
    if not v:
        return "", "", ("Cổng UNI MATE chưa chọn bộ não. Mở trang gói UNI MATE trong ChatGPT, mục Bộ não, chọn bộ "
                        f"não rồi thử lại: {trang_goi(ctx, goc)}")
    b = next((x for x in G.list_brains() if x.get("path") == v), None)
    if not b or not Path(v).is_dir():
        return "", "", (f"Bộ não đã ghim cho cổng ({Path(v).name}) không còn hoặc không mở được. Mở trang gói UNI "
                        f"MATE trong ChatGPT, mục Bộ não, chọn lại rồi thử lại: {trang_goi(ctx, goc)}")
    return v, b.get("label") or Path(v).name, ""


def vault_cho_hub(ctx) -> str:
    """Đường dẫn bộ não truyền cho hub ở các tool thường của cửa: bộ não đã ghim, hoặc rỗng (hub tự suy như cũ)."""
    v = bo_nao_ghim(ctx)
    if not v or v == GAN_NHAT or not co_ghim(_gate()) or not Path(v).is_dir():
        return ""
    return v


def _so(v, mac_dinh: int) -> int:
    try:
        return int(v)
    except (TypeError, ValueError):
        return mac_dinh


async def goi_tool_cong(ctx, rec: dict, ten: str, args: dict, muc: str, goc: str = "") -> tuple:
    """(văn bản, là_lỗi) cho một lượt gọi một trong các tool của cửa."""
    G = _gate()
    if G is None:
        return "ERROR: UNI MATE trên máy chủ cũ hơn 0.441.0, chưa có phần đọc và ghi hội thoại.", True
    if ten in _TOOL_GUI and not co_gui(G):
        return "ERROR: UNI MATE trên máy chủ cũ hơn 0.446.0, chưa có phần gửi tin vào hội thoại.", True
    if not du_muc(muc, ten):
        if ten in _TOOL_GUI:
            return (f"ERROR: Gửi tin vào hội thoại chỉ có ở mức Toàn quyền (đang là {_TEN_MUC.get(muc, muc)}). "
                    "Chủ đổi mức ở trang của gói UNI MATE trong ChatGPT."), True
        return (f"ERROR: Mức quyền hiện tại ({_TEN_MUC.get(muc, muc)}) không cho ghi. Chủ đổi mức ở trang "
                "của gói UNI MATE trong ChatGPT."), True
    brain, ten_bo_nao, loi_bo_nao = bo_nao_cong(ctx, goc)
    if loi_bo_nao:
        return f"ERROR: {loi_bo_nao}", True
    args = args if isinstance(args, dict) else {}
    try:
        if ten == T_DANH_SACH:
            kq = G.list_chats(brain, limit=_so(args.get("limit"), 20), query=str(args.get("query") or ""))
            out = {"chats": kq}
        elif ten == T_DOC:
            out = G.read_chat(str(args.get("chat_id") or ""), brain, limit=_so(args.get("limit"), 30))
        elif ten == T_GUI:
            chat_id = str(args.get("chat_id") or "").strip()
            if not chat_id and not co_ghim(G):
                return "ERROR: Tạo hội thoại mới cần UNI MATE 0.447.0 trở lên. Truyền chat_id của hội thoại có sẵn.", True
            if chat_id:
                out = await G.send_chat(chat_id, brain, str(args.get("message") or ""), nguon_cua_client(ctx, rec))
            else:
                out = await G.send_chat("", brain, str(args.get("message") or ""), nguon_cua_client(ctx, rec),
                                        title=str(args.get("title") or ""))
            out["huong_dan"] = (f"Đã gửi. Gọi {T_KET_QUA} với chat_id và after_id này để lấy câu trả lời.")
        elif ten == T_KET_QUA:
            out = await G.chat_result(str(args.get("chat_id") or ""), brain, after_id=_so(args.get("after_id"), 0),
                                      wait=_so(args.get("wait"), 25))
        else:
            out = await G.record_note(brain, nguon_cua_client(ctx, rec), str(args.get("title") or ""),
                                      str(args.get("note") or ""), asked=str(args.get("asked") or ""))
            out["da_ghi"] = f"Đã ghi vào UNI MATE: {out['title']}"
    except G.GateError as e:
        return f"ERROR: {e} (Bộ não: {ten_bo_nao})", True
    out["bo_nao"] = ten_bo_nao
    return json.dumps(out, ensure_ascii=False, default=str), False


class _MotTin:
    """Đủ cho `mcp_hub.tra_loi_jsonrpc`: hàm đó chỉ đọc thân JSON của request."""

    def __init__(self, body):
        self._body = body

    async def json(self):
        return self._body


def _la_cua_cong(m) -> bool:
    if not isinstance(m, dict):
        return False
    if m.get("method") == "tools/list":
        return True
    return m.get("method") == "tools/call" and (m.get("params") or {}).get("name") in _TOOL_CONG


async def tra_loi_mcp(ctx, rec: dict, body, muc: str, chuyen, goc: str = ""):
    """Trả lời thân JSON-RPC đã đọc. `chuyen(thân)` là đường hub thường (trả Response của Starlette).

    Tin không dính tới ba tool đi thẳng qua hub nguyên vẹn. tools/list lấy danh sách của hub rồi nối
    thêm tool của cửa; tools/call tới ba tool thì gói tự trả lời."""
    from starlette.responses import JSONResponse, Response
    tins = body if isinstance(body, list) else [body]
    if not any(_la_cua_cong(m) for m in tins):
        return await chuyen(body)
    ra = []
    for m in tins:
        if isinstance(m, dict) and m.get("method") == "tools/call" and _la_cua_cong(m):
            p = m.get("params") or {}
            van_ban, loi = await goi_tool_cong(ctx, rec, p.get("name"), p.get("arguments") or {}, muc, goc)
            r = {"jsonrpc": "2.0", "id": m.get("id"),
                 "result": {"content": [{"type": "text", "text": van_ban}], "isError": loi}}
        else:
            resp = await chuyen(m)
            if resp.status_code == 202 or not resp.body:
                continue
            r = json.loads(resp.body)
            if (isinstance(m, dict) and m.get("method") == "tools/list" and isinstance(r, dict)
                    and isinstance((r.get("result") or {}).get("tools"), list)):
                r["result"]["tools"].extend(tool_cong(muc))
        ra.append(r)
    if not ra:
        return Response(status_code=202)
    return JSONResponse(ra if isinstance(body, list) else ra[0])


# ============================================================
# HTML (chữ tối thiểu 16px, đọc trên điện thoại)
# ============================================================

_CSS = """
:root { color-scheme: light dark; --nen:#f6f5f2; --the:#fff; --chu:#1d1d1f; --phu:#6b6b70;
        --vien:#dcdad4; --nhan:#c2410c; --nhan-chu:#fff; --loi:#dc2626; --tot:#15803d; }
@media (prefers-color-scheme: dark) {
  :root { --nen:#141414; --the:#1f1f1f; --chu:#eee; --phu:#a3a3a8; --vien:#3a3a3a;
          --tot:#4ade80; --loi:#f87171; }
}
* { box-sizing: border-box; }
body { margin:0; min-height:100vh; display:flex; align-items:center; justify-content:center;
       background:var(--nen); color:var(--chu); font-size:17px; line-height:1.5;
       font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif; padding:16px; }
.the { background:var(--the); border:1px solid var(--vien); border-radius:16px; padding:28px 24px;
       width:100%; max-width:480px; }
h1 { font-size:22px; margin:0 0 8px; }
h2 { font-size:18px; margin:22px 0 8px; }
p { margin:0 0 14px; }
.phu { color:var(--phu); font-size:16px; }
ul { margin:0 0 18px; padding-left:20px; }
li { margin-bottom:6px; }
label { display:block; font-size:16px; margin:12px 0 6px; }
input, select { width:100%; font-size:17px; padding:12px; border-radius:10px;
                border:1px solid var(--vien); background:transparent; color:inherit; }
button { width:100%; font-size:17px; padding:13px; border-radius:10px; border:0; cursor:pointer;
         margin-top:12px; }
.chinh { background:var(--nhan); color:var(--nhan-chu); }
.phu-nut { background:transparent; color:var(--chu); border:1px solid var(--vien); }
.loi { color:var(--loi); font-size:16px; margin-top:10px; }
.tot { color:var(--tot); font-size:16px; margin-top:10px; }
code { font-size:16px; word-break:break-all; }
a { color:var(--nhan); }
.hop { display:flex; gap:8px; align-items:stretch; }
.hop input { flex:1; }
.hop button { width:auto; margin:0; padding:0 16px; }
"""


def _trang(than: str, status: int = 200):
    # `same-origin`, KHÔNG phải `no-referrer`. URL trang Cho phép mang state và code_challenge
    # nên không được rò sang trang khác qua Referer, và cả hai giá trị đều chặn được điều đó.
    # Nhưng `no-referrer` còn làm trình duyệt gửi `Origin: null` khi nộp form, hàng rào CSRF
    # của UNI MATE coi "null" là nguồn lạ và chặn nút Cho phép (đo trên Chromium thật 23/09).
    from starlette.responses import HTMLResponse
    return HTMLResponse(
        '<!doctype html><html lang="vi"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width,initial-scale=1">'
        '<meta name="referrer" content="same-origin"><title>UNI MATE trong ChatGPT</title>'
        f'<style>{_CSS}</style></head><body><div class="the">{than}</div></body></html>',
        status_code=status,
        headers={"Cache-Control": "no-store", "X-Frame-Options": "DENY",
                 "Content-Security-Policy": "frame-ancestors 'none'"})


_TEN_MUC = {"full": "Toàn quyền", "auto": "Ghi nháp", "suggest": "Chỉ đọc"}
_MO_TA_MUC = {
    "full": "Toàn quyền: như Ghi nháp, cộng làm việc thật ra bên ngoài (gửi tin, tạo đơn, đăng bài...)",
    "auto": ("Ghi nháp (mặc định): đọc dữ liệu, viết nháp, ghi lại điều đã chốt thành hội thoại; "
             "không làm việc ra bên ngoài"),
    "suggest": "Chỉ đọc: đọc dữ liệu và hội thoại của bạn, không ghi gì",
}


def _trang_dang_nhap():
    """Trình duyệt chưa vào dashboard: đăng nhập NGAY TẠI ĐÂY rồi tải lại, không bắt đi vòng."""
    return _trang("""
<h1>Đăng nhập UNI MATE</h1>
<p class="phu">ChatGPT hoặc Claude đang xin quyền dùng UNI MATE của bạn. Đăng nhập để xem và quyết định.</p>
<form id="f">
  <label for="u">Tài khoản</label><input id="u" name="username" autocomplete="username" required>
  <label for="p">Mật khẩu</label>
  <input id="p" name="password" type="password" autocomplete="current-password" required>
  <div id="o" style="display:none">
    <label for="c">Mã xác thực 2 lớp</label>
    <input id="c" name="code" inputmode="numeric" autocomplete="one-time-code">
  </div>
  <div id="e" class="loi" role="alert"></div>
  <button class="chinh" type="submit">Đăng nhập</button>
</form>
<script>
document.getElementById("f").onsubmit = async (ev) => {
  ev.preventDefault();
  const e = document.getElementById("e"); e.textContent = "";
  let r, d = {};
  try {
    r = await fetch("/auth/login", {method: "POST", body: new FormData(ev.target),
                                    credentials: "same-origin"});
    d = await r.json();
  } catch (x) { e.textContent = "Không gọi được UNI MATE. Thử lại."; return; }
  if (d.ok) { location.reload(); return; }
  if (d.needs_2fa) document.getElementById("o").style.display = "";
  e.textContent = d.error || "Đăng nhập không thành công.";
};
</script>""")


def _trang_dong_y(ctx, yc: dict):
    muc = muc_quyen(ctx)
    host = html.escape(urlparse(yc["redirect_uri"]).hostname or "")
    nguon = "Claude" if la_claude(yc["redirect_uri"]) else "ChatGPT"
    return _trang(f"""
<h1>Cho phép {nguon} dùng UNI MATE?</h1>
<p><b>{html.escape(yc["ten"])}</b> trên <code>{host}</code> muốn gọi công cụ của UNI MATE.</p>
<ul>
  <li>Dùng mọi kết nối bạn đã bật trong UNI MATE (bán hàng, quảng cáo, lịch, Zalo...)</li>
  <li>Đọc và ghi trong brain đang mở, tạo việc và nhắc lịch</li>
  <li>Đọc các hội thoại của bạn với UNI MATE (không đọc hội thoại khách hàng, nhóm Zalo, Team) và
      ghi lại điều đã chốt thành hội thoại mới khi bạn bảo</li>
  <li>Mức quyền: {html.escape(_MO_TA_MUC.get(muc, muc))}</li>
</ul>
<p class="phu">Đổi mức quyền hoặc ngắt kết nối bất cứ lúc nào trên trang của gói
(trang Plugin, thẻ UNI MATE trong ChatGPT, nút Mở trang).</p>
<form method="post" action="{_p(ctx, "oauth/authorize")}">
  <input type="hidden" name="yeu_cau" value="{html.escape(yc["id"])}">
  <button class="chinh" name="hanh_dong" value="cho_phep" type="submit">Cho phép</button>
  <button class="phu-nut" name="hanh_dong" value="tu_choi" type="submit">Từ chối</button>
</form>""")


def _trang_loi(cau: str, status: int = 400):
    return _trang(f"<h1>Không kết nối được</h1><p>{html.escape(cau)}</p>", status)


def _trang_cai_dat(ctx, request):
    goc = _goc(request)
    url = goc + _p(ctx, "mcp")
    muc = muc_quyen(ctx)
    https = goc.startswith("https://")
    if not _co_mat_khau():
        than_chinh = ('<p class="loi">UNI MATE chưa có mật khẩu quản trị. Bước Cho phép dựa vào '
                      'đăng nhập, nên cửa này đang đóng. Đặt mật khẩu ở Cài đặt rồi quay lại.</p>')
    else:
        chon = "".join(
            f'<option value="{m}"{" selected" if m == muc else ""}>{html.escape(_MO_TA_MUC[m])}</option>'
            for m in MUC_QUYEN)
        G = _gate()
        ghim = bo_nao_ghim(ctx)
        if co_ghim(G):
            ds = G.list_brains()
            mat = bool(ghim and ghim != GAN_NHAT and not any(b["path"] == ghim for b in ds))
            opts = ['<option value=""' + (" selected" if not ghim or mat else "") + ' disabled>Chọn bộ não...</option>']
            opts += [f'<option value="{html.escape(b["path"])}"{" selected" if b["path"] == ghim else ""}>'
                     f'{html.escape(b.get("label") or b["name"])}</option>' for b in ds]
            opts.append(f'<option value="{GAN_NHAT}"{" selected" if ghim == GAN_NHAT else ""}>'
                        'Theo hội thoại gần nhất (dễ nhảy bộ não)</option>')
            nhac = ""
            if not ghim:
                nhac = '<p class="loi">Chưa chọn bộ não: ChatGPT, Claude chưa đọc, ghi, gửi hội thoại được.</p>'
            elif mat:
                nhac = f'<p class="loi">Bộ não đã ghim ({html.escape(Path(ghim).name)}) không còn. Chọn lại.</p>'
            khoi_bo_nao = f"""
<h2>Bộ não</h2>
<p class="phu">ChatGPT, Claude đọc, ghi và gửi hội thoại trong bộ não này, không đổi theo việc bạn mở bộ não nào
trên dashboard.</p>
<select id="bo_nao">{"".join(opts)}</select>
{nhac}<div id="tb_bo_nao" class="phu" role="status"></div>"""
        else:
            khoi_bo_nao = ('<h2>Bộ não</h2><p class="phu">Chọn bộ não cố định cho cổng cần UNI MATE 0.447.0 trở lên. '
                           'Hiện cổng làm trên bộ não của hội thoại gần nhất.</p>')
        canh_bao = "" if https else (
            '<p class="loi">ChatGPT và Claude chỉ nhận địa chỉ https. Gắn tên miền riêng cho UNI MATE '
            '(Cài đặt, mục Giọng nói, thương hiệu và truy cập) rồi tải lại trang này.</p>')
        than_chinh = f"""{khoi_bo_nao}
<h2>1. Dán địa chỉ này vào ChatGPT hoặc Claude</h2>
<p class="phu">ChatGPT: Cài đặt, Apps and Connectors, Create, ô "MCP Server URL", xác thực OAuth.
Claude.ai: Cài đặt, Connectors, Add custom connector, ô "Remote MCP server URL".</p>
<div class="hop"><input id="url" readonly value="{html.escape(url)}">
<button class="phu-nut" id="chep" type="button">Chép</button></div>
{canh_bao}
<h2>2. Mức quyền của AI kết nối vào</h2>
<p class="phu">Mặc định là Ghi nháp. Muốn ChatGPT, Claude làm việc thật ra bên ngoài thì chọn Toàn quyền.</p>
<select id="muc">{chon}</select>
<div id="tb" class="phu" role="status"></div>
<h2>3. Kết nối đang dùng: <span id="so">{so_ket_noi(ctx)}</span></h2>
<button class="phu-nut" id="ngat" type="button">Ngắt mọi kết nối</button>
<script>
const tb = document.getElementById("tb");
document.getElementById("chep").onclick = async (ev) => {{
  const o = document.getElementById("url");
  try {{ await navigator.clipboard.writeText(o.value); }}
  catch (x) {{ o.select(); document.execCommand("copy"); }}
  ev.target.textContent = "Đã chép";
  setTimeout(() => ev.target.textContent = "Chép", 1500);
}};
async function goi(duong, body) {{
  const r = await fetch(duong, {{method: "POST", credentials: "same-origin",
    headers: {{"Content-Type": "application/json"}}, body: JSON.stringify(body || {{}})}});
  const d = await r.json().catch(() => ({{}}));
  if (!r.ok || !d.ok) throw new Error(d.error || ("Lỗi " + r.status));
  return d;
}}
document.getElementById("muc").onchange = async (ev) => {{
  tb.className = "phu"; tb.textContent = "Đang lưu...";
  try {{ await goi({json.dumps(_p(ctx, "cai-dat"))}, {{muc_quyen: ev.target.value}});
         tb.className = "tot"; tb.textContent = "Đã lưu. Có hiệu lực từ lượt gọi kế tiếp."; }}
  catch (x) {{ tb.className = "loi"; tb.textContent = x.message; }}
}};
const bn = document.getElementById("bo_nao");
if (bn) bn.onchange = async (ev) => {{
  const t = document.getElementById("tb_bo_nao");
  t.className = "phu"; t.textContent = "Đang lưu...";
  try {{ await goi({json.dumps(_p(ctx, "bo-nao"))}, {{bo_nao: ev.target.value}});
         t.className = "tot"; t.textContent = "Đã lưu. Có hiệu lực từ lượt gọi kế tiếp."; }}
  catch (x) {{ t.className = "loi"; t.textContent = x.message; }}
}};
document.getElementById("ngat").onclick = async () => {{
  if (!confirm("Ngắt mọi kết nối ChatGPT và Claude? Muốn dùng lại phải kết nối lại từ đó.")) return;
  try {{ await goi({json.dumps(_p(ctx, "ngat"))});
         document.getElementById("so").textContent = "0";
         tb.className = "tot"; tb.textContent = "Đã ngắt mọi kết nối."; }}
  catch (x) {{ tb.className = "loi"; tb.textContent = x.message; }}
}};
</script>"""
    return _trang(f"""
<h1>UNI MATE trong ChatGPT</h1>
<p class="phu">Chat trên chatgpt.com hoặc claude.ai bằng gói của bạn, ChatGPT hay Claude tự gọi công cụ
của UNI MATE.
<a href="{HUONG_DAN}" target="_blank" rel="noopener">Hướng dẫn từng bước</a></p>
{than_chinh}""")


# ============================================================
# Handler HTTP
# ============================================================

def _tat():
    # 404 chứ không phải 403: chưa có mật khẩu nghĩa là cửa này KHÔNG tồn tại, không quảng bá gì.
    from starlette.responses import JSONResponse
    return JSONResponse({"error": "not_found"}, status_code=404)


def _json(payload, status=200):
    from starlette.responses import JSONResponse
    return JSONResponse(payload, status_code=status,
                        headers={"Cache-Control": "no-store", "Pragma": "no-cache"})


async def _doc_form(request) -> dict:
    """Thân POST dạng form hoặc JSON. OAuth chuẩn là form; vài client gửi JSON."""
    loai = (request.headers.get("content-type") or "").lower()
    try:
        if "application/json" in loai:
            d = await request.json()
            return d if isinstance(d, dict) else {}
        return dict(await request.form())
    except Exception:
        return {}


def register(ctx):
    _giu_muc_ban_cu(ctx)

    # ---- khám phá (bắt buộc nằm ở gốc tên miền, nên đi qua register_well_known) ----
    def wk_pr(request, ctx):
        if not _co_mat_khau():
            return _tat()
        duoi = request.url.path[len("/.well-known/oauth-protected-resource"):].rstrip("/")
        if duoi not in ("", _p(ctx, "mcp")):
            return _tat()
        return _json(metadata_pr(ctx, _goc(request)))

    def wk_as(request, ctx):
        if not _co_mat_khau():
            return _tat()
        return _json(metadata_as(ctx, _goc(request)))

    ctx.register_well_known("oauth-protected-resource", wk_pr)
    ctx.register_well_known("oauth-authorization-server", wk_as)
    ctx.register_well_known("openid-configuration", wk_as)

    # ---- đăng ký client (RFC 7591) ----
    async def dang_ky(request, ctx):
        if not _co_mat_khau():
            return _tat()
        try:
            body = await request.json()
        except Exception:
            body = {}
        ma, d = dang_ky_client(ctx, body if isinstance(body, dict) else {})
        return _json(d, ma)

    ctx.register_http("oauth/register", dang_ky, methods=("POST",), public=True, no_cookie=True)

    # ---- trang Cho phép ----
    # GET công khai nhưng GIỮ cookie: chưa đăng nhập thì hiện ô đăng nhập ngay tại đó.
    # POST KHÔNG công khai: lõi UNI MATE tự đòi phiên trình duyệt thật và chặn CSRF.
    def uy_quyen(request, ctx):
        from starlette.responses import RedirectResponse
        if not _co_mat_khau():
            return _trang_loi("UNI MATE chưa có mật khẩu quản trị nên chưa kết nối được.", 404)
        kq, gia_tri = bat_dau_uy_quyen(ctx, dict(request.query_params))
        if kq == "trang_loi":
            return _trang_loi(gia_tri)
        if kq == "chuyen":
            return RedirectResponse(gia_tri, status_code=302)
        if not _co_phien(request):
            return _trang_dang_nhap()
        return _trang_dong_y(ctx, gia_tri)

    async def uy_quyen_xac_nhan(request, ctx):
        from starlette.responses import RedirectResponse
        if not _co_mat_khau():
            return _trang_loi("UNI MATE chưa có mật khẩu quản trị.", 404)
        f = await _doc_form(request)
        url = ket_thuc_uy_quyen(ctx, str(f.get("yeu_cau") or ""), f.get("hanh_dong") == "cho_phep")
        if not url:
            return _trang_loi("Yêu cầu này đã quá hạn. Mở lại ChatGPT hoặc Claude và kết nối lại.")
        return RedirectResponse(url, status_code=302)

    ctx.register_http("oauth/authorize", uy_quyen, public=True)
    ctx.register_http("oauth/authorize", uy_quyen_xac_nhan, methods=("POST",))

    # ---- đổi token + thu hồi ----
    async def token(request, ctx):
        if not _co_mat_khau():
            return _tat()
        ma, d = doi_token(ctx, await _doc_form(request))
        return _json(d, ma)

    async def thu_hoi_token(request, ctx):
        if not _co_mat_khau():
            return _tat()
        thu_hoi(ctx, str((await _doc_form(request)).get("token") or ""))
        return _json({})

    ctx.register_http("oauth/token", token, methods=("POST",), public=True, no_cookie=True)
    ctx.register_http("oauth/revoke", thu_hoi_token, methods=("POST",), public=True, no_cookie=True)

    # ---- MCP ----
    async def mcp(request, ctx):
        if not _co_mat_khau():
            return _tat()
        raw = str(request.headers.get("authorization") or "")
        raw = raw[7:].strip() if raw[:7].lower() == "bearer " else ""
        rec = kiem_token(ctx, raw)
        if not rec:
            from starlette.responses import JSONResponse
            return JSONResponse(
                {"error": "unauthorized", "error_description": "cần kết nối lại từ ChatGPT hoặc Claude"},
                status_code=401,
                headers={"WWW-Authenticate": www_authenticate(
                    ctx, _goc(request), "missing, invalid or expired token")})
        import mcp_hub
        # Mức quyền đọc TỪNG LƯỢT, không đóng băng vào token: chủ hạ quyền là có hiệu lực ngay.
        # include_ambient=False: tool native của tài khoản Claude không liên quan ở đây.
        # raw_vault: KHÔNG bao giờ nhận header từ ngoài. Chủ đã ghim bộ não trên trang gói (1.3.0) thì các tool
        # thường của hub cũng làm trên bộ não đó; chưa ghim thì để trống, hub tự suy như cũ.
        muc = muc_quyen(ctx)
        vault = vault_cho_hub(ctx) or None
        goc = _goc(request)

        async def chuyen(than):
            return await mcp_hub.tra_loi_jsonrpc(_MotTin(than), muc, include_plugins=True,
                                                 include_ambient=False, raw_vault=vault)

        try:
            body = await request.json()
        except Exception:
            # Thân hỏng: hub tự trả lỗi parse đúng chuẩn JSON-RPC.
            return await mcp_hub.tra_loi_jsonrpc(request, muc, include_plugins=True,
                                                 include_ambient=False, raw_vault=vault)
        return await tra_loi_mcp(ctx, rec, body, muc, chuyen, goc)

    def mcp_khac(request, ctx):
        # Streamable HTTP không trạng thái: không có luồng do máy chủ mở, không có phiên để xoá.
        if not _co_mat_khau():
            return _tat()
        from starlette.responses import JSONResponse
        return JSONResponse({"jsonrpc": "2.0", "id": None,
                             "error": {"code": -32000, "message": "Chỉ nhận POST."}},
                            status_code=405, headers={"Allow": "POST"})

    ctx.register_http("mcp", mcp, methods=("POST",), public=True, no_cookie=True)
    ctx.register_http("mcp", mcp_khac, methods=("GET", "DELETE"), public=True, no_cookie=True)

    # ---- trang của gói (lõi UNI MATE đòi phiên trình duyệt thật cho cả ba) ----
    ctx.register_http("", lambda request, ctx: _trang_cai_dat(ctx, request))

    async def cai_dat(request, ctx):
        f = await _doc_form(request)
        if not dat_muc_quyen(ctx, str(f.get("muc_quyen") or "")):
            return _json({"ok": False, "error": "Mức quyền không hợp lệ."}, 400)
        return _json({"ok": True, "muc_quyen": muc_quyen(ctx)})

    ctx.register_http("cai-dat", cai_dat, methods=("POST",))

    async def bo_nao(request, ctx):
        f = await _doc_form(request)
        if not dat_bo_nao(ctx, str(f.get("bo_nao") or "")):
            return _json({"ok": False, "error": "Bộ não không hợp lệ hoặc không còn. Tải lại trang rồi chọn lại."}, 400)
        return _json({"ok": True, "bo_nao": bo_nao_ghim(ctx)})

    ctx.register_http("bo-nao", bo_nao, methods=("POST",))
    ctx.register_http("ngat", lambda request, ctx: _json({"ok": True, "da_ngat": ngat_tat_ca(ctx)}),
                      methods=("POST",))
