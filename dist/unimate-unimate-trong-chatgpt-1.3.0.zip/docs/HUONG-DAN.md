# Gói `unimate.unimate-trong-chatgpt` - UNI MATE trong ChatGPT

Bạn chat trên **chatgpt.com** bằng gói ChatGPT của mình, và ChatGPT tự gọi công cụ của UNI MATE khi cần: xem doanh thu, đọc brain, tạo nhắc lịch, giao việc, gửi Zalo...

Phần suy nghĩ chạy bằng gói ChatGPT của bạn, **không tốn hạn mức Codex**. UNI MATE chỉ lo phần làm.

> Vì sao là một gói: UNI MATE giữ mọi cuộc chat chung **một nền tảng**, nên tính năng đưa chat sang chatgpt.com không bật sẵn cho mọi người. Nó từng nằm trong bản chính (0.64.21) và được tách ra thành gói ở 0.64.26. Ai cần thì cài.

---

## Trong gói có gì

| Loại | Slug | Việc |
|---|---|---|
| Plugin | `unimate-trong-chatgpt` | Cửa OAuth và địa chỉ MCP cho ChatGPT, cùng một trang cài đặt riêng |

ChatGPT dùng đúng bộ công cụ UNI MATE đã có (kết nối MCP, brain, nhắc lịch, Kanban, plugin), với mức quyền bạn chọn. Từ bản 1.1.0 có thêm ba công cụ **chỉ ChatGPT nối qua gói này mới thấy** (các engine khác của UNI MATE không thấy):

| Công cụ | Việc | Mức tối thiểu |
|---|---|---|
| `unimate_gate_list_chats` | Liệt kê hội thoại gần nhất của bạn với UNI MATE | Chỉ đọc |
| `unimate_gate_read_chat` | Đọc tin của một hội thoại | Chỉ đọc |
| `unimate_gate_record_note` | Ghi lại điều đã chốt thành hội thoại mới "Từ ChatGPT: ..." | Ghi nháp |
| `unimate_gate_send_chat` | Gửi một tin vào hội thoại ở khung Trò chuyện chính, như bạn tự gõ (từ 1.2.0); không chỉ định hội thoại thì tạo hội thoại mới (từ 1.3.0) | Toàn quyền |
| `unimate_gate_chat_result` | Lấy câu trả lời của UNI MATE cho tin vừa gửi (từ 1.2.0) | Toàn quyền |

## Cần có gì

- **UNI MATE 0.64.26 trở lên.** Bản cũ hơn thì gói bị tắt kèm lý do ngay lúc cài. Ba công cụ đọc, ghi hội thoại cần **0.441.0** trở lên; hai công cụ gửi tin cần **0.446.0** trở lên; ghim bộ não và tạo hội thoại mới cần **0.447.0** trở lên. Bản cũ hơn thì gói vẫn chạy, chỉ thiếu các công cụ đó.
- **Gói ChatGPT** Plus, Pro, Business (Team), Enterprise hoặc Edu. Gói miễn phí không có tính năng này.
- **Máy tính.** Bước cài đặt (Developer mode) chỉ làm được trên bản web chatgpt.com, không làm được trong app điện thoại.
- **UNI MATE có địa chỉ https.** ChatGPT không nhận địa chỉ kiểu `http://12.34.56.78:7777`. Gắn tên miền riêng trước (Cài đặt, mục Giọng nói, thương hiệu và truy cập).
- **UNI MATE đã đặt mật khẩu quản trị.** Bước cho phép dựa vào đăng nhập dashboard. Chưa có mật khẩu thì cửa này đóng.

---

## Bước 1: Cài gói và lấy địa chỉ

1. Mở **UNI MATE Store**, tìm **UNI MATE trong ChatGPT**, bấm cài và đồng ý chạy mã.
2. Vào trang **Plugin**, tìm thẻ **UNI MATE trong ChatGPT**, bấm **Mở trang**.
3. Bấm **Chép** để chép địa chỉ. Nó có dạng `https://ten-mien-cua-ban/ext/unimate-trong-chatgpt/mcp`.

Nếu trang báo "ChatGPT chỉ nhận địa chỉ https", xem lại phần tên miền ở trên.

## Bước 2: Chỉ khi dùng gói Business (Team)

Quản trị viên của workspace phải cho phép tạo connector riêng. Trên chatgpt.com vào **Workspace settings, Permissions & roles, Connected data**, bật **Create custom MCP connectors**.

Nếu bạn là người tạo workspace thì bạn chính là quản trị viên.

## Bước 3: Bật Developer mode trên ChatGPT

Trên chatgpt.com (máy tính): **Settings, Apps & Connectors, Advanced settings**, bật **Developer mode**.

> Tên các mục có thể hơi khác theo phiên bản ChatGPT. Tìm chữ "Developer mode" trong phần Settings.

## Bước 4: Tạo connector

Vẫn trong **Settings, Apps & Connectors**, bấm **Create** (hoặc **Add**), rồi điền:

| Ô | Điền gì |
|---|---|
| Name | `UNI MATE` |
| Description | `Trợ lý UNI MATE của tôi: số liệu, brain, nhắc việc, Zalo` |
| MCP Server URL | địa chỉ đã chép ở bước 1 |
| Authentication | **OAuth** |

Tích ô xác nhận tin tưởng connector, rồi bấm **Create**.

## Bước 5: Cho phép

ChatGPT mở một trang của UNI MATE.

- Nếu trình duyệt chưa đăng nhập UNI MATE, trang hiện ô đăng nhập ngay tại chỗ (có cả ô mã 2 lớp nếu bạn đã bật).
- Trang tiếp theo nói rõ ChatGPT được làm gì và đang ở mức quyền nào. Bấm **Cho phép**.

Xong. Quay lại ChatGPT là thấy UNI MATE đã kết nối.

## Bước 6: Dùng

Trong khung chat của ChatGPT, bấm dấu **+** (hoặc biểu tượng công cụ), chọn **Developer mode**, rồi bật **UNI MATE**. Thử:

- "Dùng UNI MATE: có những công cụ gì?"
- "Doanh thu tuần này so với tuần trước thế nào?"
- "Nhắc tôi 8 giờ sáng mai gọi nhà cung cấp."
- "Hôm qua tôi bàn gì với UNI MATE về khuyến mãi Tết? Đọc lại giúp tôi."
- "Ghi lại vào UNI MATE: chốt ngân sách Tết 50 triệu, khuyến mãi 10% từ 20/01."

Mỗi lần ChatGPT định làm một việc có tác động thật (gửi tin, tạo đơn...), nó sẽ **hỏi bạn xác nhận** trước khi gọi.

---

## Chọn bộ não cho cổng (từ bản 1.3.0)

Mở trang của gói (thẻ gói, nút Mở trang). Ô **Bộ não** nằm ngay đầu trang: chọn bộ não ChatGPT, Claude được làm việc. Từ đó cổng luôn đọc, ghi và gửi hội thoại trong bộ não này, không đổi theo việc bạn mở bộ não nào trên dashboard.

- **Chưa chọn** (cài mới hoặc vừa nâng lên 1.3.0): các công cụ hội thoại báo lỗi "Cổng UNI MATE chưa chọn bộ não..." kèm địa chỉ trang gói, để ChatGPT, Claude nhắc lại cho bạn. Gói không tự đoán bộ não, vì sau một lần khởi động lại, hội thoại mới nhất có thể nằm ở bộ não khác.
- **Theo hội thoại gần nhất** là lựa chọn phụ: cổng làm trên bộ não của hội thoại vừa cập nhật gần nhất trên cả máy, kể cả hội thoại chạy nền, nên dễ nhảy bộ não.
- Bộ não đã ghim bị xoá hoặc không mở được thì cổng báo lỗi, không tự chuyển sang bộ não khác. Mở trang gói chọn lại.
- Mọi kết quả trả cho ChatGPT, Claude đều ghi tên bộ não đang làm việc.

## Gửi tin vào hội thoại (từ bản 1.2.0)

Ở mức **Toàn quyền**, ChatGPT hoặc Claude gửi được một tin vào một hội thoại ở **khung Trò chuyện chính** của UNI MATE, như bạn tự gõ. UNI MATE trả lời ngay trong hội thoại đó: chữ chạy trên mọi tab đang mở, có nút Dừng, lưu vào Lịch sử và vòng tự học. Bong bóng tin ghi "Gửi từ ChatGPT" hoặc "Gửi từ Claude".

- Ví dụ: "Gửi cho UNI MATE trong hội thoại Kế hoạch tháng 11: lên danh sách việc tuần này, rồi đọc cho tôi câu trả lời."
- Hội thoại đang trả lời dở thì tin thành tin gõ thêm, như khi bạn gõ thêm lúc UNI MATE đang làm.
- Không chỉ định hội thoại nào (từ 1.3.0) thì tạo hội thoại mới ở khung Trò chuyện chính của bộ não đã ghim, tiêu đề "Từ ChatGPT: ..." hoặc "Từ Claude: ...".
- Chỉ khung Trò chuyện chính. Hội thoại với Cộng sự, Telegram, Zalo chỉ đọc. Hội thoại khách hàng, nhóm Zalo, Team thì không bao giờ đọc hay gửi được.
- Mức Ghi nháp và Chỉ đọc không thấy hai công cụ này.

## Dùng với Claude.ai (từ bản 1.1.0)

Cùng địa chỉ ở bước 1 cũng nối được vào **Claude.ai** (web, Desktop, điện thoại), bằng gói Claude của bạn.

1. Trên claude.ai vào **Settings, Connectors**, bấm **Add custom connector**.
2. Ô **Remote MCP server URL**: dán địa chỉ đã chép ở bước 1. Không cần điền Client ID.
3. Bấm **Add**, rồi **Connect**. Trang Cho phép của UNI MATE hiện ra, làm như bước 5.

Gói Team, Enterprise thì chủ tổ chức phải thêm connector trước. Tên các mục có thể hơi khác theo phiên bản Claude.

Mức quyền và nút **Ngắt mọi kết nối** dùng chung cho cả ChatGPT và Claude. Điều chốt bên Claude được ghi thành hội thoại **"Từ Claude: ..."**.

---

## Mức quyền

Chọn trên trang của gói (trang Plugin, nút **Mở trang**). Đổi xong có hiệu lực ngay, không cần kết nối lại.

| Mức | ChatGPT được làm gì |
|---|---|
| **Chỉ đọc** | Đọc dữ liệu và hội thoại của bạn. Không ghi gì, không làm việc ra bên ngoài |
| **Ghi nháp** (mặc định) | Như Chỉ đọc, cộng viết nháp và ghi lại điều đã chốt thành hội thoại. Không làm việc ra bên ngoài |
| **Toàn quyền** | Như Ghi nháp, cộng làm việc thật: gửi tin, tạo đơn, đăng bài |

UNI MATE tự chặn ở phía mình theo mức đã chọn. ChatGPT không tự nâng quyền được.

Từ bản 1.1.0, cài mới bắt đầu ở **Ghi nháp**. Muốn ChatGPT làm việc thật ra bên ngoài thì tự chọn Toàn quyền trên trang của gói. Ai đã cài và kết nối từ bản 1.0.0 thì **giữ nguyên mức đang chạy** (bản 1.0.0 mặc định Toàn quyền), không bị hạ giữa chừng.

**Hội thoại nào ChatGPT đọc được:** chỉ hội thoại của chính bạn với UNI MATE trong brain đang mở (dashboard, Telegram, Zalo cá nhân, chat với trợ lý). **Không bao giờ** hội thoại khách hàng, nhóm Zalo hay Team.

## Ngắt kết nối

- **Tạm dừng:** tắt plugin **UNI MATE trong ChatGPT** trên trang Plugin. Kết nối cũ giữ nguyên, bật lại là dùng tiếp.
- **Ngắt hẳn:** bấm **Ngắt mọi kết nối** trên trang của gói. Muốn dùng lại thì làm lại từ bước 4.
- **Gỡ gói:** gỡ ở UNI MATE Store. Mọi đường của gói biến mất cùng lúc.

---

## Điều cần biết trước

- **Bạn chat trong ChatGPT, không phải trong UNI MATE.** Cuộc chat nằm ở lịch sử của ChatGPT. Muốn UNI MATE nhớ điều gì thì bảo ChatGPT "ghi lại vào UNI MATE": nó tạo một hội thoại "Từ ChatGPT: ..." trong UNI MATE, vào lịch sử chat và được UNI MATE tự học như mọi lượt chat. Việc ghi này không chạy model, không tốn lượt.
- **Việc nền vẫn chạy bằng model của UNI MATE.** Nhắc lịch tự chạy, vòng lặp, bot Telegram không có ai gõ vào ChatGPT, nên chúng vẫn dùng model bạn chọn ở trang Models.
- **UNI MATE làm việc trên brain đang mở gần nhất** (brain của cuộc trò chuyện gần nhất trên dashboard). Kết quả mỗi công cụ có ghi rõ đang ở brain nào.
- **Developer mode là tính năng OpenAI còn gắn nhãn thử nghiệm.** Giao diện và tên mục của nó có thể đổi.
- **Ai từng kết nối bằng bản 0.64.21** (địa chỉ `/chatgpt/mcp`): địa chỉ đã đổi, xoá connector cũ trên ChatGPT rồi làm lại từ bước 4.

## Khi không chạy

| Bạn thấy | Nguyên nhân | Làm gì |
|---|---|---|
| Không có mục Developer mode | Gói miễn phí, hoặc đang ở app điện thoại | Dùng gói trả phí, mở chatgpt.com trên máy tính |
| Không có nút Create connector (gói Business) | Quản trị viên chưa cho phép | Làm bước 2 |
| ChatGPT báo không kết nối được server | Địa chỉ không phải https, plugin đang tắt, hoặc UNI MATE chưa có mật khẩu | Xem lại "Cần có gì" và bước 1 |
| Thẻ plugin không có nút Mở trang | UNI MATE cũ hơn 0.64.26, hoặc plugin đang tắt | Cập nhật UNI MATE, bật plugin |
| Trang UNI MATE báo "Yêu cầu này đã quá hạn" | Để trang Cho phép mở quá 10 phút | Kết nối lại từ ChatGPT |
| Đang dùng tốt bỗng bắt kết nối lại | 30 ngày không dùng, hoặc đã bấm Ngắt mọi kết nối | Kết nối lại từ ChatGPT |

## An toàn

- Token chỉ lưu dạng băm trong thư mục dữ liệu riêng của gói, không nằm trong brain.
- ChatGPT chỉ được quay về đúng máy của OpenAI (`chatgpt.com`, `*.openai.com`). Claude chỉ được quay về đúng **một** địa chỉ Anthropic công bố trong tài liệu kết nối: `https://claude.ai/api/mcp/auth_callback`, so khớp nguyên văn, không nhận địa chỉ con hay tên miền khác. Kẻ gian tự đăng ký một kết nối trỏ về máy mình sẽ không nhận được mã.
- Token của gói này tách hẳn khỏi token Claude Code và Codex dùng. Ngắt bên này không ảnh hưởng bên kia.
- Refresh token xoay vòng: một token cũ bị dùng lại là UNI MATE thu hồi cả chuỗi và bắt cho phép lại.
