# Nguồn của agent `agency-xr-cockpit-interaction-specialist`

Một agent lẻ của gói `unimate.agency-agents`, lấy từ [msitarzewski/agency-agents/spatial-computing/xr-cockpit-interaction-specialist.md](https://github.com/msitarzewski/agency-agents/blob/main/spatial-computing/xr-cockpit-interaction-specialist.md).
Thân prompt chép nguyên văn, phần đầu tệp thêm khoá cho UNI MATE (xem `docs/NGUON.md` của gói gộp).
Repo gốc đổi agent này thì gói lên một bản vá, UNI MATE báo trong chuông.

Giấy phép gốc: **MIT**, nguyên văn ở `docs/LICENSE-goc*`.
